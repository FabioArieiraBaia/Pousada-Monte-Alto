<?php
// backend/api/index.php
ob_start();

require_once __DIR__ . '/config/cors.php';
handleCORS();

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/middleware/AuthMiddleware.php';
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/AccommodationsController.php';
require_once __DIR__ . '/controllers/ReservationsController.php';
require_once __DIR__ . '/controllers/FinanceController.php';
require_once __DIR__ . '/controllers/BlogController.php';
require_once __DIR__ . '/controllers/SettingsController.php';
require_once __DIR__ . '/controllers/GalleryController.php';
require_once __DIR__ . '/controllers/VideoGalleryController.php';
require_once __DIR__ . '/controllers/AttractionsController.php';
require_once __DIR__ . '/controllers/UploadController.php';
require_once __DIR__ . '/controllers/ChatController.php';
require_once __DIR__ . '/controllers/NotificationController.php';
require_once __DIR__ . '/controllers/DashboardController.php';
require_once __DIR__ . '/controllers/PackagesController.php';
require_once __DIR__ . '/controllers/ServicesController.php';
require_once __DIR__ . '/controllers/ServiceBookingsController.php';
require_once __DIR__ . '/controllers/ServiceFinanceController.php';

$pdo = getDatabaseConnection();

$method = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['REQUEST_URI'];

// Parse URL path
$parsed = parse_url($uri, PHP_URL_PATH);

// Normalize path: strip /montealto/api, /Pousada%20Monte%20Alto/backend/api or /api
$path = preg_replace('#^/montealto/api#i', '', $parsed);
$path = preg_replace('#^/Pousada%20Monte%20Alto/backend/api#i', '', $path);
$path = preg_replace('#^/Pousada Monte Alto/backend/api#i', '', $path);
$path = preg_replace('#^/api#i', '', $path);
$path = '/' . trim($path, '/');

// Handle static uploads request directly if requested through PHP
if (preg_match('#^/uploads/(.+)$#', $path, $m)) {
    $file = __DIR__ . '/uploads/' . basename($m[1]);
    if (file_exists($file)) {
        $mime = mime_content_type($file);
        header('Content-Type: ' . $mime);
        readfile($file);
        exit();
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Arquivo não encontrado']);
        exit();
    }
}

try {
    if (ob_get_length()) ob_clean();

    // --- AUTH ROUTES ---
    if ($path === '/auth/login' && $method === 'POST') {
        AuthController::login($pdo);
        exit();
    }
    if ($path === '/auth/me' && $method === 'GET') {
        AuthController::me($pdo);
        exit();
    }

    // --- ACCOMMODATIONS ROUTES ---
    if ($path === '/accommodations' && $method === 'GET') {
        AccommodationsController::getAll($pdo, true);
        exit();
    }
    if ($path === '/accommodations/admin' && $method === 'GET') {
        AccommodationsController::getAll($pdo, false);
        exit();
    }
    if ($path === '/accommodations/check-availability' && ($method === 'POST' || $method === 'GET')) {
        AccommodationsController::checkAvailability($pdo);
        exit();
    }
    if ($path === '/accommodations' && $method === 'POST') {
        AccommodationsController::create($pdo);
        exit();
    }
    if (preg_match('#^/accommodations/(\d+)$#', $path, $m)) {
        if ($method === 'PUT') {
            AccommodationsController::update($pdo, $m[1]);
            exit();
        } elseif ($method === 'DELETE') {
            AccommodationsController::delete($pdo, $m[1]);
            exit();
        }
    }
    if (preg_match('#^/accommodations/(\d+)/photos$#', $path, $m) && $method === 'POST') {
        AccommodationsController::addPhoto($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/accommodations/photos/(\d+)$#', $path, $m) && $method === 'DELETE') {
        AccommodationsController::deletePhoto($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/accommodations/(\d+)/cover/(\d+)$#', $path, $m) && $method === 'PUT') {
        AccommodationsController::setCoverPhoto($pdo, $m[1], $m[2]);
        exit();
    }
    if (preg_match('#^/accommodations/([^/]+)$#', $path, $m) && $method === 'GET') {
        AccommodationsController::getBySlug($pdo, $m[1]);
        exit();
    }

    // --- PACKAGES ROUTES ---
    if ($path === '/packages' && $method === 'GET') {
        PackagesController::getAll($pdo);
        exit();
    }
    if ($path === '/packages' && $method === 'POST') {
        PackagesController::create($pdo);
        exit();
    }
    if (preg_match('#^/packages/(\d+)/toggle$#', $path, $m) && $method === 'PUT') {
        PackagesController::toggle($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/packages/(\d+)$#', $path, $m)) {
        if ($method === 'GET') {
            PackagesController::getById($pdo, $m[1]);
            exit();
        } elseif ($method === 'PUT') {
            PackagesController::update($pdo, $m[1]);
            exit();
        } elseif ($method === 'DELETE') {
            PackagesController::delete($pdo, $m[1]);
            exit();
        }
    }

    // --- SERVICES / TOURS ROUTES ---
    if (($path === '/services' || $path === '/passeios' || $path === '/tours') && $method === 'GET') {
        ServicesController::getAll($pdo, true);
        exit();
    }
    if (($path === '/services/admin' || $path === '/passeios/admin') && $method === 'GET') {
        ServicesController::getAll($pdo, false);
        exit();
    }
    if (($path === '/services' || $path === '/passeios') && $method === 'POST') {
        ServicesController::create($pdo);
        exit();
    }
    if (preg_match('#^/(?:services|passeios)/(\d+)/toggle$#', $path, $m) && $method === 'PUT') {
        ServicesController::toggle($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/(?:services|passeios)/(\d+)$#', $path, $m)) {
        if ($method === 'GET') {
            ServicesController::getById($pdo, $m[1]);
            exit();
        } elseif ($method === 'PUT') {
            ServicesController::update($pdo, $m[1]);
            exit();
        } elseif ($method === 'DELETE') {
            ServicesController::delete($pdo, $m[1]);
            exit();
        }
    }
    if (preg_match('#^/(?:services|passeios|tours)/([^/]+)$#', $path, $m) && $method === 'GET') {
        ServicesController::getBySlug($pdo, $m[1]);
        exit();
    }

    // --- SERVICE BOOKINGS ROUTES ---
    if ($path === '/service-bookings' && $method === 'GET') {
        ServiceBookingsController::getAll($pdo);
        exit();
    }
    if ($path === '/service-bookings/request' && $method === 'POST') {
        ServiceBookingsController::createPublic($pdo);
        exit();
    }
    if ($path === '/service-bookings' && $method === 'POST') {
        ServiceBookingsController::createAdmin($pdo);
        exit();
    }
    if (preg_match('#^/service-bookings/(\d+)/status$#', $path, $m) && $method === 'PUT') {
        ServiceBookingsController::updateStatus($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/service-bookings/(\d+)/cancel$#', $path, $m) && $method === 'POST') {
        ServiceBookingsController::cancel($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/service-bookings/(\d+)/whatsapp$#', $path, $m) && $method === 'GET') {
        ServiceBookingsController::getWhatsAppLink($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/service-bookings/(\d+)$#', $path, $m) && $method === 'DELETE') {
        ServiceBookingsController::delete($pdo, $m[1]);
        exit();
    }

    // --- SERVICE FINANCE ROUTES ---
    if ($path === '/service-finance/summary' && $method === 'GET') {
        ServiceFinanceController::getSummary($pdo);
        exit();
    }
    if ($path === '/service-finance/transactions' && $method === 'GET') {
        ServiceFinanceController::getTransactions($pdo);
        exit();
    }
    if ($path === '/service-finance/transactions' && $method === 'POST') {
        ServiceFinanceController::createTransaction($pdo);
        exit();
    }
    if (preg_match('#^/service-finance/transactions/(\d+)$#', $path, $m) && $method === 'DELETE') {
        ServiceFinanceController::deleteTransaction($pdo, $m[1]);
        exit();
    }
    if ($path === '/service-finance/export-csv' && $method === 'GET') {
        ServiceFinanceController::exportCsv($pdo);
        exit();
    }

    
    // --- ATTRACTIONS / BEACHES ROUTES ---
    if ($path === '/attractions' && $method === 'GET') {
        AttractionsController::getAll($pdo);
        exit();
    }
    if ($path === '/attractions' && $method === 'POST') {
        AttractionsController::create($pdo);
        exit();
    }
    if (preg_match('#^/attractions/(\d+)$#', $path, $m)) {
        if ($method === 'PUT') {
            AttractionsController::update($pdo, $m[1]);
            exit();
        } elseif ($method === 'DELETE') {
            AttractionsController::delete($pdo, $m[1]);
            exit();
        }
    }
    if (preg_match('#^/attractions/([^/]+)$#', $path, $m) && $method === 'GET') {
        AttractionsController::getBySlug($pdo, $m[1]);
        exit();
    }

    // --- GALLERY ROUTES ---
    if ($path === '/gallery' && $method === 'GET') {
        GalleryController::getAll($pdo);
        exit();
    }
    if ($path === '/gallery' && $method === 'POST') {
        GalleryController::create($pdo);
        exit();
    }
    if (preg_match('#^/gallery/(\d+)$#', $path, $m)) {
        if ($method === 'PUT') {
            GalleryController::update($pdo, $m[1]);
            exit();
        } elseif ($method === 'DELETE') {
            GalleryController::delete($pdo, $m[1]);
            exit();
        }
    }

    // --- VIDEO GALLERY ROUTES ---
    if (($path === '/videos' || $path === '/video-gallery') && $method === 'GET') {
        VideoGalleryController::getAll($pdo);
        exit();
    }
    if (($path === '/videos' || $path === '/video-gallery') && $method === 'POST') {
        VideoGalleryController::create($pdo);
        exit();
    }
    if (preg_match('#^/(?:videos|video-gallery)/(\d+)$#', $path, $m)) {
        if ($method === 'PUT') {
            VideoGalleryController::update($pdo, $m[1]);
            exit();
        } elseif ($method === 'DELETE') {
            VideoGalleryController::delete($pdo, $m[1]);
            exit();
        }
    }

    // --- RESERVATIONS ROUTES ---
    if ($path === '/reservations' && $method === 'GET') {
        ReservationsController::getAll($pdo);
        exit();
    }
    if ($path === '/reservations/calendar' && $method === 'GET') {
        ReservationsController::getCalendar($pdo);
        exit();
    }
    if ($path === '/reservations/request' && $method === 'POST') {
        ReservationsController::createPublic($pdo);
        exit();
    }
    if ($path === '/reservations/admin' && $method === 'POST') {
        ReservationsController::createAdmin($pdo);
        exit();
    }
    if (preg_match('#^/reservations/(\d+)/status$#', $path, $m) && $method === 'PUT') {
        ReservationsController::updateStatus($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/reservations/(\d+)/extend$#', $path, $m) && $method === 'POST') {
        ReservationsController::extendStay($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/reservations/(\d+)$#', $path, $m) && $method === 'PUT') {
        ReservationsController::updateAdmin($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/reservations/(\d+)/cancel$#', $path, $m) && $method === 'POST') {
        ReservationsController::cancelWithRefund($pdo, $m[1]);
        exit();
    }
    if (preg_match('#^/reservations/(\d+)$#', $path, $m) && $method === 'DELETE') {
        ReservationsController::delete($pdo, $m[1]);
        exit();
    }

    // --- DASHBOARD ROUTE ---
    if ($path === '/dashboard' && $method === 'GET') {
        DashboardController::getOverview($pdo);
        exit();
    }

    // --- FINANCE ROUTES ---
    if (($path === '/finance' || $path === '/finance/transactions') && $method === 'GET') {
        FinanceController::getTransactions($pdo);
        exit();
    }
    if ($path === '/finance/summary' && $method === 'GET') {
        FinanceController::getSummary($pdo);
        exit();
    }
    if ($path === '/finance/kpis' && $method === 'GET') {
        FinanceController::getKpis($pdo);
        exit();
    }
    if ($path === '/finance/by-accommodation' && $method === 'GET') {
        FinanceController::getByAccommodation($pdo);
        exit();
    }
    if ($path === '/finance/receivables' && $method === 'GET') {
        FinanceController::getReceivables($pdo);
        exit();
    }
    if ($path === '/finance/export-csv' && $method === 'GET') {
        FinanceController::exportCsv($pdo);
        exit();
    }
    if (($path === '/finance' || $path === '/finance/transactions') && $method === 'POST') {
        FinanceController::createTransaction($pdo);
        exit();
    }
    if (preg_match('#^/finance(?:/transactions)?/(\d+)$#', $path, $m) && $method === 'DELETE') {
        FinanceController::deleteTransaction($pdo, $m[1]);
        exit();
    }

    // --- BLOG ROUTES ---
    if ($path === '/blog' && $method === 'GET') {
        BlogController::getAll($pdo, true);
        exit();
    }
    if ($path === '/blog/admin' && $method === 'GET') {
        BlogController::getAll($pdo, false);
        exit();
    }
    if ($path === '/blog' && $method === 'POST') {
        BlogController::create($pdo);
        exit();
    }
    if ($path === '/blog/generate-ai' && $method === 'POST') {
        BlogController::generateWithAi($pdo);
        exit();
    }
    if (preg_match('#^/blog/(\d+)$#', $path, $m)) {
        if ($method === 'PUT') {
            BlogController::update($pdo, $m[1]);
            exit();
        } elseif ($method === 'DELETE') {
            BlogController::delete($pdo, $m[1]);
            exit();
        }
    }
    if (preg_match('#^/blog/([^/]+)$#', $path, $m) && $method === 'GET') {
        BlogController::getBySlug($pdo, $m[1]);
        exit();
    }

    // --- SETTINGS ROUTES ---
    if ($path === '/settings' && $method === 'GET') {
        SettingsController::getSettings($pdo);
        exit();
    }
    if ($path === '/settings' && $method === 'PUT') {
        SettingsController::updateSettings($pdo);
        exit();
    }

    // --- CHAT AI & CONCIERGE ROUTES ---
    if ($path === '/chat' && $method === 'POST') {
        ChatController::handleChat($pdo);
        exit();
    }
    if ($path === '/leads' && $method === 'GET') {
        ChatController::getLeads($pdo);
        exit();
    }
    if (preg_match('#^/leads/(\d+)$#', $path, $m) && $method === 'PUT') {
        ChatController::updateLeadStatus($pdo, $m[1]);
        exit();
    }
    if ($path === '/ai-config' && $method === 'GET') {
        ChatController::getPublicConfig($pdo);
        exit();
    }
    if ($path === '/ai-settings' && $method === 'GET') {
        ChatController::getAiSettings($pdo);
        exit();
    }
    if ($path === '/ai-settings' && $method === 'PUT') {
        ChatController::updateAiSettings($pdo);
        exit();
    }
    if ($path === '/ai-settings/test-keys' && $method === 'POST') {
        ChatController::testAiKeys($pdo);
        exit();
    }

    // --- PUSH & NOTIFICATIONS ROUTES ---
    if ($path === '/push/vapid-public-key' && $method === 'GET') {
        NotificationController::getVapidPublicKey($pdo);
        exit();
    }
    if ($path === '/push/subscribe' && $method === 'POST') {
        NotificationController::subscribe($pdo);
        exit();
    }
    if ($path === '/push/unsubscribe' && $method === 'POST') {
        NotificationController::unsubscribe($pdo);
        exit();
    }
    if ($path === '/notifications/settings' && $method === 'GET') {
        NotificationController::getSettings($pdo);
        exit();
    }
    if ($path === '/notifications/settings' && $method === 'PUT') {
        NotificationController::updateSettings($pdo);
        exit();
    }
    if ($path === '/notifications/test-push' && $method === 'POST') {
        NotificationController::testPush($pdo);
        exit();
    }
    if ($path === '/notifications/test-whatsapp' && $method === 'POST') {
        NotificationController::testWhatsApp($pdo);
        exit();
    }

    // --- CONTACT LEAD ROUTE ---
    if ($path === '/contact' && $method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true) ?? [];
        $name = trim($data['name'] ?? '');
        $phone = trim($data['phone'] ?? '');
        $email = trim($data['email'] ?? '');
        $message = trim($data['message'] ?? '');

        if (!empty($name) && (!empty($phone) || !empty($email))) {
            $stmt = $pdo->prepare("INSERT INTO leads_capture (name, whatsapp, email, notes, status) VALUES (?, ?, ?, ?, 'new')");
            $stmt->execute([$name, $phone, $email, $message]);
            
            require_once __DIR__ . '/services_lib/NotificationService.php';
            NotificationService::notifyNewLead($pdo, [
                'name' => $name,
                'phone' => $phone,
                'email' => $email,
                'notes' => $message,
                'source' => 'Formulário de Contato do Site'
            ]);
        }

        echo json_encode(['success' => true, 'message' => 'Mensagem recebida com sucesso!']);
        exit();
    }

    // --- UPLOAD ROUTE ---
    if ($path === '/upload' && $method === 'POST') {
        UploadController::uploadImage($pdo);
        exit();
    }

    // --- HEALTH / ROOT ---
    if ($path === '/' || $path === '') {
        echo json_encode([
            'success' => true,
            'service' => 'API Pousada Monte Alto - Arraial do Cabo',
            'version' => '1.0.0',
            'timestamp' => date('c')
        ]);
        exit();
    }

    // 404 Route Not Found
    http_response_code(404);
    echo json_encode(['error' => 'Rota não encontrada: ' . $method . ' ' . $path]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Erro interno do servidor',
        'details' => $e->getMessage()
    ]);
}
